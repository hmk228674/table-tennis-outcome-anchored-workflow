"""Illustrative boundary rules, NOT the production Skill or signal algorithms.

The synthetic examples exercise data contracts only. Passing does not establish
physiological validity, outcome-label accuracy, legal clearance or originality.
"""
from __future__ import annotations

from typing import Any


def reference_label(stroke: dict[str, Any]) -> str:
    if (
        stroke.get("feed_valid") is not True
        or stroke.get("complete") is not True
        or stroke.get("data_quality") != "illustrative_acceptable"
    ):
        return "excluded_reference"
    eligible = (
        stroke.get("feed_valid") is True
        and stroke.get("complete") is True
        and stroke.get("result_confirmed") is True
        and stroke.get("result_label") == "legal_target_hit"
        and stroke.get("data_quality") == "illustrative_acceptable"
    )
    return "result_confirmed_candidate" if eligible else "descriptive_reference"


def force_plate_labels(foot_side_confirmed: bool, mapping: dict[str, str] | None = None) -> tuple[str, str]:
    if foot_side_confirmed is True and mapping is not None:
        labels = (mapping.get("plate_1"), mapping.get("plate_2"))
        if set(labels) == {"right", "left"}:
            return labels
    return ("plate_1", "plate_2")


def bilateral_force_interpretation_allowed(window: dict[str, Any]) -> bool:
    labels = force_plate_labels(window.get("foot_side_confirmed") is True, window.get("foot_mapping"))
    return set(labels) == {"right", "left"} and window.get("complete_foot_contact_coverage") is True


def require_mvc_for_true_percent_mvc(mvc_available: bool) -> None:
    if mvc_available is not True:
        raise ValueError("True percent MVC is unavailable without valid MVC.")


def validate_case_structure(case: dict[str, Any]) -> list[str]:
    """Check a few declared fields, not authenticity or a complete schema.

    This does not inspect an athlete, EMG output, prose cue, actual task changes,
    or implicit identifiers. A synthetic flag alone never proves anonymization.
    """
    errors: list[str] = []
    if case.get("synthetic") is not True:
        errors.append("This checker only accepts explicitly synthetic fixtures.")
    if not case.get("case_id") or not case.get("technical_scope") or not case.get("strokes"):
        errors.append("Illustrative case identity, nonempty technique scope and strokes are required.")
    strokes = {stroke["trial_id"]: stroke for stroke in case.get("strokes", [])}
    if len(strokes) != len(case.get("strokes", [])):
        errors.append("Duplicate trial IDs.")
    for reference in case.get("references", []):
        ids = reference.get("trial_ids", [])
        if any(trial_id not in strokes for trial_id in ids):
            errors.append("Reference cites nonexistent stroke.")
            continue
        if reference.get("representative_trial_id") not in ids:
            errors.append("Representative must be an actual member.")
        if reference.get("template_type") == "Golden Set":
            if not 3 <= len(set(ids)) <= 5 or len(set(ids)) != len(ids):
                errors.append("Example Golden Set needs three to five eligible strokes.")
            if any(strokes[trial_id].get("technique_id") != reference.get("technique_id") for trial_id in ids):
                errors.append("Golden Set must belong to the declared technique.")
            if any(reference_label(strokes[trial_id]) != "result_confirmed_candidate" for trial_id in ids):
                errors.append("Golden Set contains unconfirmed or unsuccessful result.")
    evidence_ids = {entry["evidence_id"] for entry in case.get("evidence_items", [])}
    task_ids = set(case.get("technical_scope", []))
    covered = set()
    for exercise in case.get("exercises", []):
        covered.add(exercise.get("technique_id"))
        links = exercise.get("evidence_ids", [])
        if not links or not set(links).issubset(evidence_ids):
            errors.append("Exercise has missing or dangling evidence links.")
        if exercise.get("format") != "one_to_one_coach_racket_multiball":
            errors.append("Exercise violates required training format.")
        if exercise.get("primary_cue_count") != 1:
            errors.append("Exercise must have one primary cue.")
        if not isinstance(exercise.get("primary_variable"), str):
            errors.append("Exercise must name one primary variable.")
        if not exercise.get("retest_variable"):
            errors.append("Exercise lacks a retest variable.")
    if covered != task_ids:
        errors.append("Training coverage differs from actual valid technique scope.")
    return errors
