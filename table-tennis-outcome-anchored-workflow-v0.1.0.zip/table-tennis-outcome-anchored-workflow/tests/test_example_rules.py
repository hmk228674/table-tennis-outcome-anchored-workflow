"""Run: python3 -m unittest discover -s tests -v (from public_candidate)."""
from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from example_rules import (
    bilateral_force_interpretation_allowed,
    force_plate_labels,
    reference_label,
    require_mvc_for_true_percent_mvc,
    validate_case_structure,
)

FIXTURE = Path(__file__).resolve().parents[1] / "examples" / "synthetic" / "example_case.json"


class SyntheticContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.case = json.loads(FIXTURE.read_text(encoding="utf-8"))

    def test_constructed_fixture_is_consistent(self) -> None:
        self.assertEqual(validate_case_structure(self.case), [])

    def test_unknown_result_never_golden(self) -> None:
        self.assertEqual(reference_label(self.case["strokes"][-1]), "descriptive_reference")

    def test_unknown_result_in_golden_set_rejected(self) -> None:
        self.case["references"][0]["trial_ids"][0] = "SYNTH-B-01"
        self.assertIn("Golden Set contains unconfirmed or unsuccessful result.", validate_case_structure(self.case))

    def test_false_mvc_flag_raises_expected_boundary_error(self) -> None:
        with self.assertRaises(ValueError):
            require_mvc_for_true_percent_mvc(False)

    def test_unknown_foot_side_uses_platform_names(self) -> None:
        self.assertEqual(force_plate_labels(False), ("plate_1", "plate_2"))

    def test_confirmed_mapping_is_not_assumed_right_first(self) -> None:
        self.assertEqual(force_plate_labels(True, {"plate_1": "left", "plate_2": "right"}), ("left", "right"))

    def test_confirmation_without_mapping_uses_platform_names(self) -> None:
        self.assertEqual(force_plate_labels(True), ("plate_1", "plate_2"))

    def test_repeated_stroke_cannot_make_a_golden_set(self) -> None:
        self.case["references"][0]["trial_ids"] = ["SYNTH-A-02"] * 3
        self.assertIn("Example Golden Set needs three to five eligible strokes.", validate_case_structure(self.case))

    def test_cross_technique_golden_set_rejected(self) -> None:
        self.case["references"][0]["technique_id"] = "TECH-B"
        self.assertIn("Golden Set must belong to the declared technique.", validate_case_structure(self.case))

    def test_empty_case_is_not_a_valid_structural_example(self) -> None:
        self.assertIn("Illustrative case identity, nonempty technique scope and strokes are required.", validate_case_structure({"synthetic": True}))

    def test_foot_off_platform_blocks_bilateral_transfer_inference(self) -> None:
        self.assertFalse(bilateral_force_interpretation_allowed(self.case["force_window_example"]))

    def test_unobserved_foot_coverage_is_not_true(self) -> None:
        self.assertFalse(bilateral_force_interpretation_allowed({"foot_side_confirmed": True}))

    def test_exercise_needs_existing_evidence(self) -> None:
        self.case["exercises"][0]["evidence_ids"] = ["NONEXISTENT"]
        self.assertIn("Exercise has missing or dangling evidence links.", validate_case_structure(self.case))

    def test_all_actual_techniques_must_be_covered(self) -> None:
        self.case["exercises"].pop()
        self.assertIn("Training coverage differs from actual valid technique scope.", validate_case_structure(self.case))

    def test_extra_technique_must_not_be_invented(self) -> None:
        extra = copy.deepcopy(self.case["exercises"][0])
        extra["exercise_id"] = "EX-INVENTED"
        extra["technique_id"] = "NOT_UPLOADED"
        self.case["exercises"].append(extra)
        self.assertIn("Training coverage differs from actual valid technique scope.", validate_case_structure(self.case))

    def test_multiple_cues_rejected(self) -> None:
        self.case["exercises"][0]["primary_cue_count"] = 2
        self.assertIn("Exercise must have one primary cue.", validate_case_structure(self.case))

    def test_automatic_feeder_rejected(self) -> None:
        self.case["exercises"][0]["format"] = "ball_machine"
        self.assertIn("Exercise violates required training format.", validate_case_structure(self.case))

    def test_false_synthetic_flag_rejected(self) -> None:
        self.case["synthetic"] = False
        self.assertIn("This checker only accepts explicitly synthetic fixtures.", validate_case_structure(self.case))

    def test_invalid_feed_is_not_a_descriptive_reference(self) -> None:
        stroke = copy.deepcopy(self.case["strokes"][-1])
        stroke["feed_valid"] = False
        self.assertEqual(reference_label(stroke), "excluded_reference")

    def test_incomplete_stroke_is_not_a_descriptive_reference(self) -> None:
        stroke = copy.deepcopy(self.case["strokes"][-1])
        stroke["complete"] = False
        self.assertEqual(reference_label(stroke), "excluded_reference")


if __name__ == "__main__":
    unittest.main()
