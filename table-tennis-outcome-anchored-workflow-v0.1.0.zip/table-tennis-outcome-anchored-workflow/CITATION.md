# 引用 / Citation

Han, Mingke (韩明珂). (2026). *An outcome-anchored auditable workflow for table-tennis multimodal assessment and individualized multiball planning*, version 0.1.0.

作者单位：South China Normal University / 华南师范大学。
ORCID: https://orcid.org/0009-0009-3980-662X

引用时补充实际访问的GitHub Release URL或Zenodo具体版本DOI。此文件不预填尚未登记的DOI；Zenodo发布后以实际记录生成的规范引用为准。版本冻结内容见RELEASE_MANIFEST.json。

This is a method specification with illustrative synthetic tests, not a validated
automatic biomechanical analysis package or an athlete dataset. Cite the version
you actually used, not only the latest-version concept identifier.
