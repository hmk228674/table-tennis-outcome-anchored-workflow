# Changelog

## 0.1.0

- Initial public method-specification release, with five protocol/schema/validation/disclosure/related-work documents.
- Includes a wholly synthetic structural example and 20 illustrative rule unit tests.
- Explicitly separates professional/manual analysis from implemented helper tooling.
- Adds confirmed author metadata and file-specific CC BY 4.0 / MIT licensing.
- Does not include real participants, raw signals, identifiable reports, commercial source, patent filings, or claimed validation results.

Local review candidates preceded this release; their creation times are not public
priority evidence. Public publication dates and identifiers are those recorded by
the hosting services, not dates inferred from local files.
