# 相关工作与待验证的具体贡献

本文件不是系统综述、专利新颖性意见或“查无同类”的证明。检索到的论文、专利在公开日期、实施与主张范围上不同；未逐一认定为任何法域的法定现有技术。候选流程不能笼统宣称首个多模态乒乓球评估或个性化教练系统。

## 代表性原始研究

| 原始工作 | 已存在的相关内容 | 本候选需要进一步比较什么 |
|---|---|---|
| He et al., 2022, *Lower Limb Muscle Forces in Table Tennis Footwork during Topspin Forehand Stroke Based on the OpenSim Musculoskeletal Model: A Pilot Study* | 同步动作捕捉、测力台和肌电；成功试次筛选及个体化模型 | 结果确认的本人动作集合、逐条训练关联与纵向验证是否有实质新方法。[出版社原文](https://www.techscience.com/mcb/v19n4/50857/html) |
| Ma et al., 2025, *Table tennis coaching system based on a multimodal large language model with a table tennis knowledge base* | 视频/姿态与知识库生成个性化建议 | 质量门槛、逐板结果和证据台账不能仅靠改名声称新颖。[出版社原文](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0317839) |
| Ma et al., 2025, *T3Set: A Multimodal Dataset with Targeted Suggestions for LLM-based Virtual Coach in Table Tennis Training* | 对齐视频、球拍IMU与教练建议；证据包支持建议生成 | 本候选的不同数据模态、结果模板与练习可追溯机制需要实际对照。[作者原文](https://ssxiexiao.github.io/papers/t3set.pdf) |
| Chen, 2026, *EdgeFusionNet: real-time multimodal feedback for table tennis training via lightweight cross-modal attention fusion on edge-cloud collaborative architecture* | 视觉、IMU和sEMG融合及训练反馈 | 没有理由把“多模态反馈”作为本项目首创；其性能数字不属于本项目。[出版社原文](https://www.nature.com/articles/s41598-026-58591-y) |
| Ma et al., 2024, *avaTTAR: Table Tennis Stroke Training with Embodied and Detached Visualization in Augmented Reality* | 三维动作参考、时间对齐与纠错显示 | 同一人成功动作参照与专家参照的差异、稳定性及训练迁移仍需验证。[出版记录](https://doi.org/10.1145/3654777.3676400)，[作者预印本](https://arxiv.org/html/2407.15373v2) |

这些研究各有样本、设计和验证限制。列出它们不代表复现或认可其所有效果主张；也不能拿本候选缺少同样模块作为优越性证明。

## 本候选可供同行检验的设计对象

| 具体设计 | 当前状态 | 要证明价值还缺什么 |
|---|---|---|
| 全输入审计、分级、缺失信息补充与强制等待 | 历史工具部分实现，本协议进一步明确 | 各模态漏问/错配回归与真实场景验证 |
| 结果先于信号定义个人高表现集合 | 方法规范，示例只演示结构 | 独立结果标注、选择算法、重复采集与选择偏差分析 |
| 足撤出测力台时停止双足负荷转换推断 | 安全解释规则，不是新传感器算法 | 接触掩码、同步误差、阈值敏感性与参考测量 |
| 观察—解释—训练假设—练习—复测的稳定ID关联 | 流程结构与少量合成规则测试 | 独立审阅、纠错能力、跨版本一致性与完整实现 |
| 胶皮、水平、时间、计分与反馈配置适配 | 服务设计要求 | 是否改善客户理解、执行依从性与实际表现 |
| 两文档共享事实模型并逐页验收 | 历史辅助工具+人工流程 | 对真实成品的全面一致性和视觉验收评估 |

这些是**候选贡献对象**，不是已证明的世界首次创新。下一步应对具体特征扩展中文论文、跨运动任务、专利族与引用链检索，并建立能被反证的比较实验；不能从“此次没见完全一样”推导首发。
