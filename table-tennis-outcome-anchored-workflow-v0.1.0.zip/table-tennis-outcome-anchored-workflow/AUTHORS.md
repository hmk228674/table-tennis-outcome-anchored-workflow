# 作者 / Author

- 中文姓名：韩明珂
- English name: Han Mingke
- Family name: Han; given name: Mingke
- 单位：华南师范大学 / South China Normal University
- ORCID: https://orcid.org/0009-0009-3980-662X

本版本按提交者确认的署名与公开权限发布，没有列入未提供姓名的合作者。单位列为作者所属机构，不代表单位对效果、原创性或商业服务背书。该声明不是独立法律权属认证。

方法说明、结构与合成示例使用AI辅助组织、起草和检查；AI不列为作者。署名人负责内容审阅，其他使用者需自行验证实际分析与训练应用。
